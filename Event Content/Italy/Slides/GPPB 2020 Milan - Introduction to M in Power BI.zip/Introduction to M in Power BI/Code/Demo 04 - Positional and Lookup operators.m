
// Query 01 - Positional index operator returns an item (number) of the list

let 
    MyList = {1..31},
    Result = MyList{6}
in 
    Result

// Query 02 - Positional index operator returns an item (text) of the list
let 
    MyList = {"Francesco","Lorenzo","Marco","Fabio"},
    Result = MyList{0}
in 
    Result

// Query 03 - Lookup index returns a value from a field of a record
let 
    MyRecord = [firstname="Francesco", lastname="De Chirico", city="Milan", age=53],
    Result = MyRecord[firstname]
in 
    Result

// Query 04 - Positional index operator returns a single row from a table
let 
    MyTable = #table( 
                        {"Product", "Sales"}, 
                        { 
                            {"PC", 100},
                            {"Monitor", 150} 
                        } 
                    ),
    Result = MyTable{0}
in 
    Result    

// Query 05 - Lookup index returns a list with all the values of a column from a table
let 
    MyTable = #table( 
                        {"Product", "Sales"}, 
                        { 
                            {"PC", 100},
                            {"Monitor", 150} 
                        } 
                    ),
    Result = MyTable[Product]
in 
    Result 

// Query 06 - Both operators return the value of a column for a specific row from a table
let 
    MyTable = #table( 
                        {"Product", "Sales"}, 
                        { 
                            {"PC", 100},
                            {"Monitor", 150} 
                        } 
                    ),
    Result = MyTable[Product]{0}
in 
    Result 