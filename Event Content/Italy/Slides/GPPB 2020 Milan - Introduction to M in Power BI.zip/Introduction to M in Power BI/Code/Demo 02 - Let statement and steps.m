/* Demo 02 - Let statement and steps */

// Query 01: same result
let 
    step1 = 5,
    step2 = 10,
    step3 = step1 * step2
in 
    step3
// or
let 
    step1 = 5,
    step2 = 10,
    step3 = step1 * step2
in 
    5 * 10
// or
let 
    step1 = 5,
    step2 = 10,
    step3 = step1 * step2
in 
    step1 * step2

// Query 02: change definition order does not change execution order
let 
    step3 = step1 * step2,
    step1 = 5,
    step2 = 10
in 
    step3

// Query 03: steps not executed (1 and 3)
let 
    step1 = 5,
    step2 = 10,
    step3 = step1 * step2
in 
    step2

// Query 04: DON'T DO THIS!
let
	Step1 = Step4 - 12,
	Step2 = 3 + Step3,
	Step3 = Step6 * Step1,
	Step4 = 7,
	Step5 = Step4 + Step2,
	Step6 = 2
in
	Step5
    
// Also show how to reference another query simply selecting it from the UI intellisense