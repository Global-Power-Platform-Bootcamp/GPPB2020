/* Demo 03 - Data Types */


/* PRIMITIVE VALUES */

// Query 01 - Value returned is a text
= "hello world" 

// Query 02 - Value returned (2) is a number
= 1 + 1 

// Query 03 - Value returned is a logical
= true 

// Query 04 - Value returned is a null value
= null 

// Query 05 - Value returned is ∞
= +#infinity 

// Query 06 - Value returned is NaN (Not-a-number)
= #nan 


/* COMPLEX OBJECTS 1: LISTS */

// Query 01 - List of three numbers
= {1, 2, 3} 

// Query 02 - List of two text
= {"Hello","world"} 

// Query 03 - List of mix values
= {123, true, "A"} //

// Query 04 - List of range of values
= {1..31} 

// Query 05 - List of lists (nested lists)
= {{"Francesco","Lorenzo"},{"Marco","Fabio"}} 

// Query 06 - Concatenate 2 lists
= {1,2} & {3,4,5}
= {3,4,5} & {1,2} //-> Not sorted!

// Query 07 - Compare 2 lists (order is important!)
= {1,2} = {3,4,5}
= {1,2} <> {3,4,5}
= {3,4,5} <> {3,4,5}
= {3,4,5} <> {3,5,4}



/* COMPLEX OBJECTS 2: RECORDS */

// Query 01 - A simple record
= [firstname="Francesco", lastname="De Chirico", city="Milan", age=53]

// Query 02 - Add fields to records using "&" operator
let 
	MyRecord = [firstname="Francesco", lastname="De Chirico", city="Milan", age=53],
	MyNewRecord = MyRecord & [ID=100]
in 
	MyNewRecord

// Query 03 - Update fields of records using "&" operator
let 
	MyRecord = [firstname="Francesco", lastname="De Chirico", city="Milan", age=53, ID=100],
	MyNewRecord = MyRecord & [ID=300]
in 
	MyNewRecord	

// Query 04 - Compare records (order doesn't matter) 
= [ID=100, Name="Francesco"] <> [ID=100, Name="Francesco"]
= [ID=100, Name="Francesco"] = [ID=100, Name="Francesco"]
= [ID=100, Name="Francesco"] <> [Name="Francesco", ID=100]
= [ID=100, Name="Francesco"] = [Name="Francesco", ID=100]



/* COMPLEX OBJECTS 3: TABLES */

// Query 01
= #table( {"Product", "Sales"}, { {"PC", 100}, {"Monitor", 150} } )

// Query 02
= #table(type table [Product = text, Sales = number], { {"PC", 100}, {"Monitor", 150} } )

// Query 03
= Table.FromRows( { {"PC", 100}, {"Monitor", 150} }, {"Product", "Sales"} )

// Query 04
= Table.FromRecords( { [Product="PC", Sales=100], [Product="Monitor", Sales= 150] } )




