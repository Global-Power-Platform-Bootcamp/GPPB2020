//Query 01 - If ... then ... else
let
    Test = 1 = 2,
    ThenBranch = "This is ThenBranch",
    ElseBranch = "This is ElseBranch",
    Result = if Test = false 
            then ThenBranch
            else ElseBranch
in
    Result