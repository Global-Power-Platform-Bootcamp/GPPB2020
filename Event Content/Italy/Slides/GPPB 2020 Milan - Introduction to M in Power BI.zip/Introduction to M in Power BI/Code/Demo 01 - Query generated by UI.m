/* Demo 01 - Create this query with UI */

let
    Source = Csv.Document(File.Contents("c:\Users\fdechirico\OneDrive\Power BI\Power BI - Events\Power Platform Bootcamp\Introduction to M in Power BI\Data\Countries.csv"),[Delimiter=",", Columns=2, Encoding=65001, QuoteStyle=QuoteStyle.None]),
    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{{"continent_name", type text}, {"country_name", type text}}),
    #"Filtered Rows" = Table.SelectRows(#"Changed Type", each ([continent_name] = "Europe")),
    #"Sorted Rows" = Table.Sort(#"Filtered Rows",{{"country_name", Order.Ascending}})
in
    #"Sorted Rows"